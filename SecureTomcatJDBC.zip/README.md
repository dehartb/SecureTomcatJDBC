# SecureTomcatJDBC
SecureTomcatJDBC Encrypt the Passwords in the Context.xml

For further reference https://www.middlewareinventory.com/blog/secure-tomcat-jdbc/
